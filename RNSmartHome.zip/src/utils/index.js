import images from './images';
import {COLORS, SIZES, FONTS} from './theme';

export {images, COLORS, SIZES, FONTS};
