module.exports = {
  assets: ['./src/assets/fonts/'],
};
// https://console.firebase.google.com/u/0/project/smarthome-57342/overview
