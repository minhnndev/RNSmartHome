export const Users = [
  {
    id: 1,
    email: 'admin@tmplatform.com',
    username: 'admin',
    password: '123456',
    tokenAccount: 'tokenadmin',
  },
  {
    id: 2,
    email: 'smarthome@tmplatform.com',
    username: 'smarthome',
    password: '12345678',
    tokenAccount: 'smarthomevjppro',
  },
  {
    id: 3,
    email: 'support@tmplatform.com',
    username: 'tmplatform',
    password: '23456789',
    tokenAccount: 'tmplatformpoor',
  },
  {
    id: 4,
    email: 'ipxauvc@tmplatform.com',
    username: '45.119.212.43',
    password: '4511921243',
    tokenAccount: 'ipxauvaicalol',
  },
  {
    id: 5,
    email: 'minhnndev@tmplatform.com',
    username: 'minhnndev',
    password: 'minhnndev',
    tokenAccount: 'sieucapvjppro',
  },
];
